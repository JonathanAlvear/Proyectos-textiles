﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsumosMedicosJDJ.Models
{
    public class Personas
    {
        public int Id_detalle_cliente { get; set; }

        public string Cedula { get; set; }

        public string Nombres { get; set; }

        public string Apellidos { get; set; }

        public float MyProperty { get; set; }

        public string Telefono { get; set; }


    }
}

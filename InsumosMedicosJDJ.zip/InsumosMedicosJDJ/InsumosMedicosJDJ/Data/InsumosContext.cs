﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using InsumosMedicosJDJ.Models;

namespace InsumosMedicosJDJ.Data
{
    public class InsumosContext : DbContext
    {
        public InsumosContext (DbContextOptions<InsumosContext> options)
            : base(options)
        {
        }

        public DbSet<Producciones> Producciones { get; set; }
    }
}
